Leftover component for statboard. NOTE: May not function properly as required token is administrator only.
